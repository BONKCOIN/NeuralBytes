﻿
Imports System.Threading

Public Class Form1
    ' Constants
    Const CELL_SIZE_DEFAULT As Integer = 20
    Const GRID_WIDTH_DEFAULT As Integer = 40
    Const GRID_HEIGHT_DEFAULT As Integer = 30
    Const CELL_COLOR_ALIVE As Integer = &HFF000000
    Const CELL_COLOR_DEAD As Integer = &HFFFFFFFF

    ' Game grid
    Dim grid(,) As Boolean

    ' Simulation thread
    Dim simulationThread As Thread
    Dim isRunning As Boolean = False
    Dim resetGrid As Boolean = True

    ' Random number generator
    Dim rand As New Random()

    Private CELL_SIZE As Integer = CELL_SIZE_DEFAULT
    Private GRID_WIDTH As Integer = GRID_WIDTH_DEFAULT
    Private GRID_HEIGHT As Integer = GRID_HEIGHT_DEFAULT


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MsgBox("Press Spacebar to Play and Pause Simmulation. Enjoy!")
        InitializeGrid()
    End Sub


    Private Sub Form1_Resize(sender As Object, e As EventArgs) Handles MyBase.Resize
        ' Calculate the new cell size based on the current form size
        Dim newCellSize As Integer = Math.Min(Math.Floor(Width / GRID_WIDTH_DEFAULT), Math.Floor(Height / GRID_HEIGHT_DEFAULT))

        ' Update the grid size
        CELL_SIZE = newCellSize
        GRID_WIDTH = Width \ CELL_SIZE
        GRID_HEIGHT = Height \ CELL_SIZE

        ' Update the grid and redraw
        InitializeGrid()
        DrawGrid()
    End Sub

    Private Sub InitializeGrid()
        ReDim grid(GRID_WIDTH, GRID_HEIGHT) ' Initialize the grid with the correct size
        For x As Integer = 0 To GRID_WIDTH - 1
            For y As Integer = 0 To GRID_HEIGHT - 1
                grid(x, y) = rand.Next(2) = 0 ' Randomly initialize cells
            Next
        Next
    End Sub



    Private Sub DrawGrid()
        Dim bmp As New Bitmap(GRID_WIDTH * CELL_SIZE, GRID_HEIGHT * CELL_SIZE)

        Using g As Graphics = Graphics.FromImage(bmp)
            For x As Integer = 0 To GRID_WIDTH - 1
                For y As Integer = 0 To GRID_HEIGHT - 1
                    Dim cellRect As New Rectangle(x * CELL_SIZE, y * CELL_SIZE, CELL_SIZE, CELL_SIZE)
                    If grid(x, y) Then
                        g.FillRectangle(New SolidBrush(Color.FromArgb(CELL_COLOR_ALIVE)), cellRect)
                    Else
                        g.FillRectangle(New SolidBrush(Color.FromArgb(CELL_COLOR_DEAD)), cellRect)
                    End If
                Next
            Next
        End Using

        picBox.Image = bmp
    End Sub


    Private Sub UpdateGrid()
        Dim newGrid(GRID_WIDTH, GRID_HEIGHT) As Boolean

        For x As Integer = 0 To GRID_WIDTH
            For y As Integer = 0 To GRID_HEIGHT
                Dim aliveNeighbors As Integer = CountAliveNeighbors(x, y)

                If grid(x, y) Then
                    ' Cell is alive
                    newGrid(x, y) = aliveNeighbors = 2 OrElse aliveNeighbors = 3
                Else
                    ' Cell is dead
                    newGrid(x, y) = aliveNeighbors = 3
                End If
            Next
        Next

        grid = newGrid
    End Sub

    Private Function CountAliveNeighbors(x As Integer, y As Integer) As Integer
        Dim count As Integer = 0

        For xOffset As Integer = -1 To 1
            For yOffset As Integer = -1 To 1
                If xOffset = 0 AndAlso yOffset = 0 Then
                    Continue For ' Skip the current cell
                End If

                Dim neighborX As Integer = (x + xOffset + GRID_WIDTH) Mod GRID_WIDTH
                Dim neighborY As Integer = (y + yOffset + GRID_HEIGHT) Mod GRID_HEIGHT

                If grid(neighborX, neighborY) Then
                    count += 1
                End If
            Next
        Next

        Return count
    End Function




    Private Sub SimulateGameOfLife()
        While isRunning
            UpdateGrid()
            Me.Invoke(Sub() DrawGrid())
            Thread.Sleep(100) ' Adjust the speed of the simulation
        End While

        If resetGrid Then
            InitializeGrid()
            Me.Invoke(Sub() DrawGrid())
        End If
    End Sub

    Protected Overrides Sub OnFormClosing(e As FormClosingEventArgs)
        MyBase.OnFormClosing(e)
        If simulationThread IsNot Nothing AndAlso simulationThread.IsAlive Then
            simulationThread.Abort()
        End If
    End Sub

    Private Sub picBox_Click(sender As Object, e As EventArgs) Handles picBox.Click

    End Sub

    Private Sub Form1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles MyBase.KeyPress
        ' Check if the spacebar key is pressed (ASCII code 32)
        If Asc(e.KeyChar) = 32 Then
            If isRunning Then
                isRunning = False
                resetGrid = True
            Else
                isRunning = True
                resetGrid = False
                simulationThread = New Thread(AddressOf SimulateGameOfLife)
                simulationThread.Start()
            End If
        End If
    End Sub

End Class
