// Created by JEDA@2023
// NEURALBYTES.ORG
// Define a flag to track if the request has been sent
var requestSent = false;

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === 'extract_text' && !requestSent) {
    var textElements = document.querySelectorAll('.markdown.prose.w-full.break-words.dark\\:prose-invert.light');

    if (textElements.length > 0) {
      // Get the last element with the specified class
      var lastTextElement = textElements[textElements.length - 1];
      var extractedText = lastTextElement.innerText;

      // Send the extracted text as a POST request to neuralbytes.org/chatgpt/
      sendPostRequest(extractedText);
      
      // Set the flag to indicate that the request has been sent
      requestSent = true;
    } else {
      // No Matching elements
    }
  }
});

function sendPostRequest(extractedText) {
  // Construct the POST request
  var url = 'https:///neuralbytes.org/chatgpt/';
  var formData = new FormData();
  formData.append('msg', extractedText);

  // Make the POST request
  fetch(url, {
    method: 'POST',
    body: formData
  })
    .then(response => {
      if (response.ok) {
        // Request was successful
      } else {
        // Request failed
      }
    })
    .catch(error => {
      // Error occurred
    });
}

