//Created by JEDA@2023
//NEURALBYTES.ORG
chrome.browserAction.onClicked.addListener(function(tab) {
  chrome.tabs.executeScript(tab.id, { file: "content.js" }, function() {
    chrome.tabs.sendMessage(tab.id, { action: "extract_text" }, function(response) {
      if (chrome.runtime.lastError) {
        console.error(chrome.runtime.lastError);
      } else {
        chrome.tabs.create({ url: 'about:blank' }, function(newTab) {
          chrome.scripting.executeScript(newTab.id, {
            code: 'document.body.innerText = ' + JSON.stringify(response.text),
          });
        });
      }
    });
  });
});


