//Created by JEDA@2023
//NEURALBYTES.ORG
document.addEventListener('DOMContentLoaded', function() {
  var extractButton = document.getElementById('extractButton');

  extractButton.addEventListener('click', function() {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        function: extractText
      });
    });
  });
});

function extractText() {
  var text = document.body.innerText;
  chrome.runtime.sendMessage({ action: 'extracted_text', text: text });
}


